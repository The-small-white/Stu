# Three
========
ref:https://www.bilibili.com/video/av65313713?p=1<br>
This is a source code of Yang Xu(MicroSoft MVP)'s ASP.Net 3.X tutorial,p1 to p6<br>
I wrote all the code by hand during study<br>
Variables names might be different, but the project works perfectly<br>



参考资源：https://www.bilibili.com/video/av65313713?p=1<br>
这是杨旭(微软Mvp)制作的ASP.net 3.x教学中p1到p6部分的源码<br>
是我在学习过程中手敲记录下来的<br>
部分变量名称与视频中可能会有出入，但并不影响程序运行
