﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Three
{
    public class ThreeOptions
    {
        public int BoldDepartmentEmployeeCountThreshold { get; set; }
    }
}
